export const ACCESS_TOKEN = 'access_token';
export const USER = 'user';