export enum ReportReason {
  Profanity = 0,
  Misinformation = 1,
  Irrelevant = 2,
  ViolenceOrHate = 3,
  Spam = 4
}
