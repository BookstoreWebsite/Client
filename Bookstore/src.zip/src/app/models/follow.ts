export interface Follow {
  id: string;
  username: string;
  profilePicture: string;
  firstName: string;
  lastName: string;
}
