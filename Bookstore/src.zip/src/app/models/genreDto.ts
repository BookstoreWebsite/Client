export interface GenreDto {
  id: string;
  name: string;
}
