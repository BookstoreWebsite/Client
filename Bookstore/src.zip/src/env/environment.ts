export const environment = {
    apiUrl: 'https://localhost:44340/api'
};